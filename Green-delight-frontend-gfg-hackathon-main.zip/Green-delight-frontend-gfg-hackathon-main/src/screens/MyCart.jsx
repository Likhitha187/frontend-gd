import React from "react";
import Navbar from "../components/Navbar";
import Cart from "../components/Cart";

export default function MyCart(){
    return(
        <div>
            <Navbar></Navbar>
    <Cart></Cart>
        </div>
    )
    
}